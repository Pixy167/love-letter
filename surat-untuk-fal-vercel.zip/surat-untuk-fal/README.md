# A Special Letter Just For You

Situs statis (tanpa build). Struktur:

- `index.html` : halaman utama
- `assets/` : foto (`*.jpg`) dan lagu (`kekal.mp3`)
- `vercel.json` : konfigurasi Vercel (opsional)

## Deploy ke Vercel

**Lewat CLI**
```
npm i -g vercel
cd surat-untuk-fal
vercel --prod
```

**Lewat GitHub**
1. Push folder ini ke repo GitHub.
2. vercel.com > Add New > Project > import repo.
3. Framework Preset: Other, Build Command dikosongkan, lalu Deploy.

## Tes lokal
```
python3 -m http.server 8000
```
Buka http://localhost:8000
